package com.luv2code.springdemo.gofoodie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GofoodieApplication {
	public static void main(String[] args)
	{
		SpringApplication.run(GofoodieApplication.class, args);
	}
}
