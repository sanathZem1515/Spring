package com.luv2code.springdemo.gofoodie.mapper;

import com.luv2code.springdemo.gofoodie.dto.HotelDto;
import com.luv2code.springdemo.gofoodie.entity.Hotel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface HotelMapper
{
    HotelMapper INSTANCE = Mappers.getMapper(HotelMapper.class);

//    @Mapping(source = "hotel.id" , target = "theId")
    HotelDto EntityToDto(Hotel theHotel);
    Hotel DtoToEntity(HotelDto theHotelDto);

    List<HotelDto> EntitiesToDtos(List<Hotel> theHotels);
    List<Hotel> DtosToEntities(List<HotelDto> theHotelDtos);

}
