package com.luv2code.springdemo.gofoodie.controller;

import com.luv2code.springdemo.gofoodie.Exceptions.Food.FoodNotFoundException;
import com.luv2code.springdemo.gofoodie.Exceptions.Hotel.HotelNotFoundException;
import com.luv2code.springdemo.gofoodie.dto.FoodDto;
import com.luv2code.springdemo.gofoodie.entity.Food;
import com.luv2code.springdemo.gofoodie.entity.Hotel;
import com.luv2code.springdemo.gofoodie.service.FoodService;
import com.luv2code.springdemo.gofoodie.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/customer")
public class CustomerController
{
    @Autowired
    private HotelService hotelService;

    @Autowired
    private FoodService foodService;

    @GetMapping("/")
    public String display(Model theModel)
    {
        List<Hotel> theHotels = hotelService.findAll();
        theModel.addAttribute("hotels", theHotels);
        return "customer/customer-form";
    }

    @GetMapping("/hotel")
    public String displayFoods(@RequestParam String hotelName, Model theModel)
    {
        Hotel hotel = hotelService.findByHotelName(hotelName);

        if(hotel==null)
            throw new  HotelNotFoundException("Hotel name not found "+ hotelName);
        List<FoodDto> theFoods = foodService.findAllByHotelName(hotelName);
        System.out.println(theFoods);
        if(theFoods.size()==0)
            throw new FoodNotFoundException("No Food found! ");

        theModel.addAttribute("foods",theFoods);
        return "customer/items";
    }
}
