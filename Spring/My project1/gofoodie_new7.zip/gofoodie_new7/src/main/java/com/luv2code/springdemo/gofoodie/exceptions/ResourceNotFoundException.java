package com.luv2code.springdemo.gofoodie.exceptions;

public class ResourceNotFoundException extends RuntimeException
{
}
